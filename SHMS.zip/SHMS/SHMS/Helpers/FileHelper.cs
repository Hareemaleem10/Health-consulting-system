﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SHMS.Helpers
{
    public class FileHelper
    {
        public static IHostingEnvironment env { get; set; }

        public static string Upload(IFormFile file,string folder="uploads")
        {
            try
            {
                var name = Guid.NewGuid().ToString() + file.FileName;
                var folderPath = Path.Combine(env.WebRootPath, folder);

                var filePath = Path.Combine(folderPath, name);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                };
                return name;
            }
            catch
            {
                return null;
            }
        }

        public static bool Delete(string filename, string folder = "uploads")
        {
            try
            {
                if (filename != "placeholder.png")
                {
                    var folderPath = Path.Combine(env.WebRootPath, folder);
                    var filePath = Path.Combine(folderPath, filename);
                    File.Delete(filePath);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHMS.Helpers;
using SHMS.Models;

namespace SHMS.Controllers
{
    public class DepartmentsController : Controller
    {
        private string GetSession(string key)
        {
            return HttpContext.Session.GetString(key);
        }
        private SHMSContext _context;

        public DepartmentsController(SHMSContext context)
        {
            _context = context;
        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            var data = _context.TblDepartments.ToList();
            return View(data);
        }

        public IActionResult Create()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            return View();
        }
        public IActionResult Edit(int Id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            var data = _context.TblDepartments.FirstOrDefault(a => a.Id == Id);
            return View(data);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TblDepartments entity)
        {
           if(ModelState.IsValid)
            {
                entity.Icon = FileHelper.Upload(entity.FormFile);
                _context.TblDepartments.Add(entity);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(entity);
        }

        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(TblDepartments entity)
        {
            if(entity!=null)
            {
                if (entity.FormFile != null)
                {
                    FileHelper.Delete(entity.Icon);
                    entity.Icon = FileHelper.Upload(entity.FormFile);
                }

                _context.TblDepartments.Update(entity);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(entity);
        }

        public IActionResult Delete(int Id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            var data = _context.TblDepartments.Where(a => a.Id == Id).FirstOrDefault();
            if(data!=null)
            {
                _context.TblDepartments.Remove(data);
                _context.SaveChanges();
                FileHelper.Delete(data.Icon);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}

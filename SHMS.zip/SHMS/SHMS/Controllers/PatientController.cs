﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SHMS.Models;

namespace SHMS.Controllers
{
    public class PatientController : Controller
    {
        private string GetSession(string key)
        {
            return HttpContext.Session.GetString(key);
        }
        private readonly SHMSContext _context;

        public PatientController(SHMSContext context)
        {
            _context = context;
        }

        // GET: Patient
        public async Task<IActionResult> Index()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            return View(await _context.TblPatients.ToListAsync());
        }

        // GET: Patient/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblPatients = await _context.TblPatients
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tblPatients == null)
            {
                return NotFound();
            }

            return View(tblPatients);
        }

        // GET: Patient/Create
        public IActionResult Create()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            return View();
        }

        // POST: Patient/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,FatherName,Email,Password,ConfirmPassword,Phone,Address,Photo")] TblPatients tblPatients)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (ModelState.IsValid)
            {
                _context.Add(tblPatients);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tblPatients);
        }

        // GET: Patient/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblPatients = await _context.TblPatients.FindAsync(id);
            if (tblPatients == null)
            {
                return NotFound();
            }
            return View(tblPatients);
        }

        // POST: Patient/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,FatherName,Email,Password,ConfirmPassword,Phone,Address,Photo")] TblPatients tblPatients)
        {
            if (id != tblPatients.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tblPatients);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TblPatientsExists(tblPatients.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tblPatients);
        }

        // GET: Patient/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblPatients = await _context.TblPatients
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tblPatients == null)
            {
                return NotFound();
            }

            return View(tblPatients);
        }

        // POST: Patient/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tblPatients = await _context.TblPatients.FindAsync(id);
            _context.TblPatients.Remove(tblPatients);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TblPatientsExists(int id)
        {
            return _context.TblPatients.Any(e => e.Id == id);
        }
    }
}

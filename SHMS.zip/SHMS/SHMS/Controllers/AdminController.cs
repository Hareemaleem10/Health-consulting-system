﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SHMS.Models;

namespace SHMS.Controllers
{
    public class AdminController : Controller
    {
        private SHMSContext _context;

        public AdminController(SHMSContext context)
        {
            _context = context;
        }

        private string GetSession(string key)
        {
            return HttpContext.Session.GetString(key);
        }

        private void SetSession(string key, string value)
        {
            HttpContext.Session.SetString(key, value);
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email,string password)
        {
            var data = _context.TblUsers.Where(a => a.Email == email && a.Password == password).FirstOrDefault();
            if(data!=null)
            { 
                SetSession("UserData",JsonConvert.SerializeObject(data));
                return RedirectToAction(nameof(Dashboard));
            }
            else
            {
                ViewBag.msg = "Login failed! wrong email or password!!";
                return View();
            }
        }
        public IActionResult Dashboard()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            return View();
        }

        public IActionResult Profile()
        {
            if(GetSession("UserData")==null)
            {
                return RedirectToAction(nameof(Login));
            }
            var data = JsonConvert.DeserializeObject<TblUsers>(GetSession("UserData"));
            return View(data);
        }

        [HttpPost]
        public IActionResult Profile(TblUsers user)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            if (ModelState.IsValid)
            {
                _context.TblUsers.Update(user);
                _context.SaveChanges();
                SetSession("UserData", JsonConvert.SerializeObject(user));
            }
            return View(user);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction(nameof(Login));
        }

        
    }
}
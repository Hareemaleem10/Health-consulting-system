﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using SHMS.Models;

namespace SHMS.Controllers
{
    public class DoctorController : Controller
    {
        private SHMSContext _context;
        public DoctorController(SHMSContext context)
        {
            _context = context;
        }

        private string GetSession(string key)
        {
            return HttpContext.Session.GetString(key);
        }

        private void SetSession(string key, string value)
        {
            HttpContext.Session.SetString(key, value);
        }

     
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email,string password)
        {
            var data = _context.TblDoctors.FirstOrDefault(a => a.Email == email && a.Password == password);
            if(data!=null)
            {
                SetSession("UserData", JsonConvert.SerializeObject(data));
                return RedirectToAction(nameof(Dashboard));
            }
            else
            {
                ViewBag.msg = "Login Failed!!! Wrong email or password";
            }
            return View();
        }

        public IActionResult Dashboard()
        {
            if(GetSession("UserData")==null)
            {
                return RedirectToAction(nameof(Login));
            }
            return View();
        }

        public IActionResult ChangePassword()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            return View();
        }


        [HttpPost]
        public IActionResult ChangePassword(string newPassword,string confirmPassword)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            var data = JsonConvert.DeserializeObject<TblDoctors>(GetSession("UserData"));
           if(newPassword.Equals(confirmPassword))
            {
                data.Password =newPassword;
                data.ConfirmPassword = confirmPassword;
                _context.TblDoctors.Update(data);
                _context.SaveChanges();
                ViewBag.msg = "Password has been updated successfully";
            }
            else
            {
                ViewBag.msg = "New Password and Confirm password must be same!!";
            }
            return View();
        }

        public IActionResult Appoinments()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            int Id = JsonConvert.DeserializeObject<TblDoctors>(GetSession("UserData")).Id;
            return View(_context.TblAppoinments.Include(a=>a.Patient).Where(a => a.DoctorId==Id).ToList());

        }
        public IActionResult Schedules()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            int Id = JsonConvert.DeserializeObject<TblDoctors>(GetSession("UserData")).Id;
            return View(_context.TblSchedule.Include(a => a.Doctor).Where(a => a.DoctorId == Id).ToList());
        }

        public IActionResult AppoinmentDetail(int Id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            var appoinment = _context.TblAppoinments.Include(a => a.Patient).Include(a => a.Doctor).Where(a => a.Id == Id).FirstOrDefault();
            return View(appoinment);
        }


        public IActionResult UpdateStatus(int Id,string status)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            var data = _context.TblAppoinments.FirstOrDefault(a => a.Id == Id);
           if(data!=null)
            {
                data.Status = status;
                _context.TblAppoinments.Update(data);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Appoinments));
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction(nameof(Login));
        }
        
        public IActionResult Chats()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            int Id = JsonConvert.DeserializeObject<TblDoctors>(GetSession("UserData")).Id;
            var data = _context.TblChats.Where(a => a.DoctorId == Id).ToList();

            return View(data);
        }

        public IActionResult GetChat(int Id)
        {
            var data = _context.TblMessages.Where(a => a.ChatId == Id).ToList();

            return View(data);

        }

        public string Send(string message, int chatId)
        {
            int pid = JsonConvert.DeserializeObject<TblDoctors>(GetSession("UserData")).Id;
            var chat = _context.TblChats.Where(a => a.Id == chatId).FirstOrDefault();
            var msg = new TblMessages()
            {
                DateTime = DateTime.Now,
                PatientId = chat.PatientId,
                Message = message,
                ChatId = chatId
            };
            _context.TblMessages.Add(msg);
            _context.SaveChanges();
            return "success";
        }


    }
}
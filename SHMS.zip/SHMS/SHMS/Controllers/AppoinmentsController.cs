﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SHMS.Models;

namespace SHMS.Controllers
{
  
    public class AppoinmentsController : Controller
    {

        private string GetSession(string key)
        {
            return HttpContext.Session.GetString(key);
        }
        private readonly SHMSContext _context;

        public AppoinmentsController(SHMSContext context)
        {
            _context = context;
        }

        // GET: Appoinments
        public async Task<IActionResult> Index()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login","Admin");
            }
            var sHMSContext = _context.TblAppoinments.Include(t => t.Doctor).Include(t => t.Patient);
            return View(await sHMSContext.ToListAsync());
        }

        // GET: Appoinments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblAppoinments = await _context.TblAppoinments
                .Include(t => t.Doctor)
                .Include(t => t.Patient)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tblAppoinments == null)
            {
                return NotFound();
            }

            return View(tblAppoinments);
        }

        // GET: Appoinments/Create
        public IActionResult Create()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            ViewData["DoctorId"] = new SelectList(_context.TblDoctors, "Id", "Address");
            ViewData["PatientId"] = new SelectList(_context.TblPatients, "Id", "Address");
            return View();
        }

        // POST: Appoinments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,DoctorId,PatientId,ScheduleId,Status")] TblAppoinments tblAppoinments)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tblAppoinments);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["DoctorId"] = new SelectList(_context.TblDoctors, "Id", "Address", tblAppoinments.DoctorId);
            ViewData["PatientId"] = new SelectList(_context.TblPatients, "Id", "Address", tblAppoinments.PatientId);
            return View(tblAppoinments);
        }

        // GET: Appoinments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblAppoinments = await _context.TblAppoinments.FindAsync(id);
            if (tblAppoinments == null)
            {
                return NotFound();
            }
            ViewData["DoctorId"] = new SelectList(_context.TblDoctors, "Id", "Address", tblAppoinments.DoctorId);
            ViewData["PatientId"] = new SelectList(_context.TblPatients, "Id", "Address", tblAppoinments.PatientId);
            return View(tblAppoinments);
        }

        // POST: Appoinments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DoctorId,PatientId,ScheduleId,Status")] TblAppoinments tblAppoinments)
        {
            if (id != tblAppoinments.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tblAppoinments);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TblAppoinmentsExists(tblAppoinments.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DoctorId"] = new SelectList(_context.TblDoctors, "Id", "Address", tblAppoinments.DoctorId);
            ViewData["PatientId"] = new SelectList(_context.TblPatients, "Id", "Address", tblAppoinments.PatientId);
            return View(tblAppoinments);
        }

        // GET: Appoinments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblAppoinments = await _context.TblAppoinments
                .Include(t => t.Doctor)
                .Include(t => t.Patient)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tblAppoinments == null)
            {
                return NotFound();
            }

            return View(tblAppoinments);
        }

        // POST: Appoinments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tblAppoinments = await _context.TblAppoinments.FindAsync(id);
            _context.TblAppoinments.Remove(tblAppoinments);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TblAppoinmentsExists(int id)
        {
            return _context.TblAppoinments.Any(e => e.Id == id);
        }
    }
}

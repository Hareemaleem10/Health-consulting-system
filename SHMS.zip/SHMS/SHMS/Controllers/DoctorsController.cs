﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SHMS.Helpers;
using SHMS.Models;

namespace SHMS.Controllers
{
    public class DoctorsController : Controller
    {
        private string GetSession(string key)
        {
            return HttpContext.Session.GetString(key);
        }
        private readonly SHMSContext _context;

        public DoctorsController(SHMSContext context)
        {
            _context = context;
        }

        // GET: Doctors
        public async Task<IActionResult> Index()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            var sHMSContext = _context.TblDoctors.Include(t => t.Depart);
            return View(await sHMSContext.ToListAsync());
        }

        // GET: Doctors/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblDoctors = await _context.TblDoctors
                .Include(t => t.Depart)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tblDoctors == null)
            {
                return NotFound();
            }

            return View(tblDoctors);
        }

        // GET: Doctors/Create
        public IActionResult Create()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            ViewData["DepartId"] = new SelectList(_context.TblDepartments, "Id", "Name");
            return View();
        }

        // POST: Doctors/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,FatherName,Email,Password,ConfirmPassword,Specialization,Address,Phone,Photo,Status,DepartId")] TblDoctors tblDoctors,IFormFile Photo)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (ModelState.IsValid)
            {
                if (Photo != null)
                {
                  tblDoctors.Photo= FileHelper.Upload(Photo);
                }
                _context.Add(tblDoctors);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["DepartId"] = new SelectList(_context.TblDepartments, "Id", "Name", tblDoctors.DepartId);
            return View(tblDoctors);
        }

        // GET: Doctors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblDoctors = await _context.TblDoctors.FindAsync(id);
            if (tblDoctors == null)
            {
                return NotFound();
            }
            ViewData["DepartId"] = new SelectList(_context.TblDepartments, "Id", "Name", tblDoctors.DepartId);
            return View(tblDoctors);
        }

        // POST: Doctors/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,FatherName,Email,Password,ConfirmPassword,Specialization,Address,Phone,Photo,Status,DepartId")] TblDoctors tblDoctors,IFormFile Photo1)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id != tblDoctors.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (Photo1 != null)
                    {
                        FileHelper.Delete(tblDoctors.Photo);
                        tblDoctors.Photo = FileHelper.Upload(Photo1);
                    }

                    _context.Update(tblDoctors);
                    await _context.SaveChangesAsync();
                  
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TblDoctorsExists(tblDoctors.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DepartId"] = new SelectList(_context.TblDepartments, "Id", "Name", tblDoctors.DepartId);
            return View(tblDoctors);
        }

        // GET: Doctors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            if (id == null)
            {
                return NotFound();
            }

            var tblDoctors = await _context.TblDoctors
                .Include(t => t.Depart)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tblDoctors == null)
            {
                return NotFound();
            }

            return View(tblDoctors);
        }

        // POST: Doctors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction("Login", "Admin");
            }
            var tblDoctors = await _context.TblDoctors.FindAsync(id);
            _context.TblDoctors.Remove(tblDoctors);
            await _context.SaveChangesAsync();
            FileHelper.Delete(tblDoctors.Photo);
            return RedirectToAction(nameof(Index));
        }

        private bool TblDoctorsExists(int id)
        {
            return _context.TblDoctors.Any(e => e.Id == id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using SHMS.Helpers;
using SHMS.Models;
using SHMS.ViewModels;

namespace SHMS.Controllers
{
    public class PatientsController : Controller
    {
        private readonly SHMSContext _context;

        public PatientsController(SHMSContext context)
        {
            _context = context;
        }

        // GET: Patients
        public  IActionResult Index()
        {
            return View(new IndexViewModel(_context));
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult Departments()
        {
            var data = _context.TblDepartments;
            return View(data);
        }

        public IActionResult Doctors(int Id=0)
        {
            var data = _context.TblDoctors.Include(a => a.Depart);
            var dataList = data.ToList();
            if (Id!=0)
            {
                dataList = data.Where(a => a.DepartId == Id).ToList();
            }
           
            return View(dataList);
        }

    
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        { 
            var data =await _context.TblPatients.FirstOrDefaultAsync(a => a.Email == email && a.Password == password);
            if(data!=null)
            {
                var jsonString = JsonConvert.SerializeObject(data);
                SetSession("UserData", jsonString);
                return RedirectToAction(nameof(Profile));
            }

            else
            {
                ViewBag.msg = "Login failed! Wrong email or password!!!!";
                return View();
            }
        }

        public IActionResult Profile()
        {
            if(GetSession("UserData")==null)
            {
                return RedirectToAction(nameof(Login));
            }
            var data = JsonConvert.DeserializeObject<TblPatients>(GetSession("UserData"));
            return View(data);
        }

        [HttpPost]
        public IActionResult Profile(TblPatients patient,IFormFile Image)
        {
            if(ModelState.IsValid)
            {
                if(Image!=null)
                {
                    FileHelper.Delete(patient.Photo);
                    patient.Photo = FileHelper.Upload(Image);
                }
                _context.TblPatients.Update(patient);
                _context.SaveChanges();
                SetSession("UserData", JsonConvert.SerializeObject(patient));
                return RedirectToAction(nameof(Profile));
            }
            return View(patient);
        }
        public IActionResult Register()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Register(TblPatients patient,IFormFile Photo)
        {
            if(ModelState.IsValid)
            {
                patient.Photo = FileHelper.Upload(Photo);
                _context.TblPatients.Add(patient);
                await _context.SaveChangesAsync();
                var jsonString = JsonConvert.SerializeObject(patient);
                SetSession("UserData", jsonString);
                return RedirectToAction(nameof(Profile));
            }
            else
            {
                return View(patient);
            }
        }


        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction(nameof(Login));
        }
        public IActionResult Appoinment()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            ViewData["DoctorId"] = new SelectList(_context.TblDoctors, "Id", "Name");
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Appoinment(TblAppoinments appoinment)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
              appoinment.PatientId = JsonConvert.DeserializeObject<TblPatients>(GetSession("UserData")).Id;
                _context.Add(appoinment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Appoinments));
            
        }

        public IActionResult Appoinments()
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            var data = _context.TblAppoinments.Include(a => a.Doctor).Include(a => a.Patient);
            return View(data);
        }

        public IActionResult Chats(int? Id)
        {
            if (GetSession("UserData") == null)
            {
                return RedirectToAction(nameof(Login));
            }
            int pid = JsonConvert.DeserializeObject<TblPatients>(GetSession("UserData")).Id;
            var dat = _context.TblChats.Where(a => a.PatientId == pid && a.DoctorId == Id).FirstOrDefault();
           
            if (Id!=null&&dat==null)
            {

                var chat = new TblChats() {
                    DoctorId = Id,
                    PatientId = pid
                };
                _context.TblChats.Add(chat);
                _context.SaveChanges();
            }
            var data = _context.TblChats.Where(a => a.PatientId == pid).ToList();
            return View(data);
        }

        public string Send(string message,int chatId)
        {
            int pid = JsonConvert.DeserializeObject<TblPatients>(GetSession("UserData")).Id;
            var chat = _context.TblChats.Where(a => a.Id == chatId).FirstOrDefault();
            var msg = new TblMessages() { 
                DateTime=DateTime.Now,
                DoctorId=chat.DoctorId,
                Message=message,
                ChatId=chatId
            };
            _context.TblMessages.Add(msg);
            _context.SaveChanges();
            return "success";
        }

        public IActionResult GetChat(int Id)
        {
            var data = _context.TblMessages.Where(a=>a.ChatId==Id).ToList();

            return View(data);
            
        }

        private string GetSession(string key)
        {
          return  HttpContext.Session.GetString(key);
        }

        public void SetSession(string key,string value)
        {
            HttpContext.Session.SetString(key, value);
        }

       
      
    }
}

﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SHMS.Models
{
    public partial class TblDepartments
    {
        public TblDepartments()
        {
            TblDoctors = new HashSet<TblDoctors>();
        }

        public int Id { get; set; }

        [Required(ErrorMessage ="Name is Required!!!!!")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Detail cannot be empty!!!!!"), DataType(DataType.MultilineText)]
        public string Detail { get; set; }
        public string Icon { get; set; } = "placeholder.png";

        [NotMapped]
        public IFormFile FormFile { get; set; }

        public virtual ICollection<TblDoctors> TblDoctors { get; set; }
    }
}

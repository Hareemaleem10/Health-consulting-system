﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace SHMS.Models
{
    public partial class TblAppoinments
    {
        public int Id { get; set; }

        [Required,Display(Name ="Doctor")]
        public int? DoctorId { get; set; }

        [Required, Display(Name = "Patient")]
        public int? PatientId { get; set; }

        [Required, Display(Name = "Schedule")]
        public int? ScheduleId { get; set; }

        [Required]
        public string Status { get; set; }

        public virtual TblDoctors Doctor { get; set; }
        public virtual TblPatients Patient { get; set; }
        public TblSchedule GetSchedule()
        {
            var data= new SHMSContext().TblSchedule.FirstOrDefault(a => a.Id == ScheduleId);
            if(data==null)
            {
                data = new TblSchedule();
            }
            return data;
        }
    }
}

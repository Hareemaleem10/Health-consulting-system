﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SHMS.Models
{
    public partial class TblSchedule
    {
        public int Id { get; set; }
        [Required]
        public string Day { get; set; }

        [Required]
        public string Time { get; set; }

        [Required,Display(Name ="Doctor")]
        public int? DoctorId { get; set; }

        public virtual TblDoctors Doctor { get; set; }
        

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SHMS.Models
{
    public partial class TblMessages
    {
        public int Id { get; set; }

        [Required]
        public int? ChatId { get; set; }

        [Required]
        public int? DoctorId { get; set; }

        [Required]
        public int? PatientId { get; set; }

        [Required]
        public DateTime? DateTime { get; set; }

        [Required]
        public string Message { get; set; }

    }
}

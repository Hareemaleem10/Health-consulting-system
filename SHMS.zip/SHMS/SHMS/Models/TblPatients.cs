﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SHMS.Models
{
    public partial class TblPatients
    {
        public TblPatients()
        {
            TblAppoinments = new HashSet<TblAppoinments>();
            
        }

        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string FatherName { get; set; }

        [Required,DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required, DataType(DataType.Password)]
        public string Password { get; set; }


        [Required, DataType(DataType.Password),Compare("Password")]
        public string ConfirmPassword { get; set; }

        [Required, DataType(DataType.PhoneNumber)]
        public string Phone { get; set; }

        [Required, DataType(DataType.MultilineText)]
        public string Address { get; set; }

        public string Photo { get; set; }

        public virtual ICollection<TblAppoinments> TblAppoinments { get; set; }
     
    }
}

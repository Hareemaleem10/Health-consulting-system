﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SHMS.Models
{
    public partial class TblUsers
    {
        public int Id { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required, DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required, DataType(DataType.Password)]
        public string Password { get; set; }

        [Required, DataType(DataType.Password), Compare("Password")]
        public string ConfirmPassword { get; set; }

        [Required]
        public int? UserType { get; set; }
    }
}

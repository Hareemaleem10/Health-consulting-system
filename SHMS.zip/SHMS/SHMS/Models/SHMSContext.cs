﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SHMS.Models
{
    public partial class SHMSContext : DbContext
    {
        public SHMSContext()
        {
            this.Database.EnsureCreated();
        }

        public SHMSContext(DbContextOptions<SHMSContext> options)
            : base(options)
        {
            this.Database.EnsureCreated();
        }

        public virtual DbSet<TblAppoinments> TblAppoinments { get; set; }
        public virtual DbSet<TblDepartments> TblDepartments { get; set; }
        public virtual DbSet<TblDoctors> TblDoctors { get; set; }
        public virtual DbSet<TblPatients> TblPatients { get; set; }
        public virtual DbSet<TblSchedule> TblSchedule { get; set; }
        public virtual DbSet<TblUsers> TblUsers { get; set; }
        public virtual DbSet<TblChats> TblChats { get; set; }

        public virtual DbSet<TblMessages> TblMessages { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer(@"Data Source=DESKTOP-Q23DGQ2;Database=SHMS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
              
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<TblAppoinments>(entity =>
            {
                entity.ToTable("tblAppoinments");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.DoctorId).HasColumnName("doctorId");

                entity.Property(e => e.PatientId).HasColumnName("patientId");

                entity.Property(e => e.ScheduleId).HasColumnName("scheduleId");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.TblAppoinments)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK_tblAppoinments_tblDoctors");

                entity.HasOne(d => d.Patient)
                    .WithMany(p => p.TblAppoinments)
                    .HasForeignKey(d => d.PatientId)
                    .HasConstraintName("FK_tblAppoinments_tblPatients");
            });

         
            modelBuilder.Entity<TblDepartments>(entity =>
            {
                entity.ToTable("tblDepartments");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Detail)
                    .HasColumnName("detail")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Icon)
                    .HasColumnName("icon")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblDoctors>(entity =>
            {
                entity.ToTable("tblDoctors");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ConfirmPassword)
                    .HasColumnName("confirmPassword")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DepartId).HasColumnName("departId");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FatherName)
                    .HasColumnName("fatherName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Photo)
                    .HasColumnName("photo")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Specialization)
                    .HasColumnName("specialization")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status).HasColumnName("status");

                entity.HasOne(d => d.Depart)
                    .WithMany(p => p.TblDoctors)
                    .HasForeignKey(d => d.DepartId)
                    .HasConstraintName("FK_tblDoctors_tblDepartments");
            });

          
            modelBuilder.Entity<TblPatients>(entity =>
            {
                entity.ToTable("tblPatients");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ConfirmPassword)
                    .HasColumnName("confirmPassword")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FatherName)
                    .HasColumnName("fatherName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Photo)
                    .HasColumnName("photo")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblSchedule>(entity =>
            {
                entity.ToTable("tblSchedule");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Day)
                    .HasColumnName("day")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DoctorId).HasColumnName("doctorId");

                entity.Property(e => e.Time)
                    .HasColumnName("time")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.TblSchedule)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK_tblSchedule_tblDoctors");
            });

            modelBuilder.Entity<TblUsers>(entity =>
            {
                entity.ToTable("tblUsers");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ConfirmPassword)
                    .HasColumnName("confirmPassword")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasColumnName("firstName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasColumnName("lastName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserType).HasColumnName("userType");
            });


            modelBuilder.Entity<TblChats>(entity =>
            {
                entity.ToTable("tblChat");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.DoctorId)
                    .HasColumnName("doctorId").IsRequired(false);

                entity.Property(e => e.PatientId)
                    .HasColumnName("patientId").IsRequired(false);

              
            });

            modelBuilder.Entity<TblMessages>(entity =>
            {
                entity.ToTable("tblMessage");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.DoctorId)
                    .HasColumnName("doctorId").IsRequired(false);

                entity.Property(e => e.PatientId)
                    .HasColumnName("patientId").IsRequired(false);

                entity.Property(e => e.Message)
                   .HasColumnName("message");

                entity.Property(e => e.DateTime)
                    .HasColumnName("dateTime");

                entity.Property(e => e.ChatId)
                   .HasColumnName("chatId");

            });
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using SHMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SHMS.ViewModels
{
    public class IndexViewModel
    {
        private SHMSContext _context;

        public IndexViewModel(SHMSContext context)
        {
            _context = context;
        }
        public IEnumerable<TblDepartments> GetDepartments()
        {
            return _context.TblDepartments;
        }
        public IEnumerable<TblSchedule> GetSchedules()
        {
            return _context.TblSchedule.Include(a=>a.Doctor).Take(5);
        }
    }
}
